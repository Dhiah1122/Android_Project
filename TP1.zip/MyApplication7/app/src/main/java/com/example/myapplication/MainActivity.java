package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText txtnom,txtprenom;
    private Button btnvalid;
    private TextView lblres;
    private  RadioButton rd1,rd2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.txtnom = (EditText) this.findViewById(R.id.txtnom);
        this.txtprenom = (EditText) this.findViewById(R.id.txtprenom);

        this.btnvalid = (Button) this.findViewById(R.id.btnvalid);
        this.lblres = (TextView) this.findViewById(R.id.lblres);
        this.rd1 = (RadioButton) this.findViewById(R.id.rd1);
        this.rd2 = (RadioButton) this.findViewById(R.id.rd2);

        this.btnvalid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1 = txtnom.getText().toString();
                String s2 = txtprenom.getText().toString();

                String res = "Bonjour " + " "+s1 + " "+s2+" !";
                lblres.setText(res);
                if (rd1.isChecked()) {

                    lblres.setTextColor(Color.BLUE);
                }

                if (rd2.isChecked()) {

                    lblres.setTextColor(Color.RED);
                }


            }
        });

this.rd1.setOnClickListener(new View.OnClickListener() {

    @Override
    public void onClick(View v) {
        rd2.setChecked(false);
    }
});

this.rd2.setOnClickListener(new View.OnClickListener() {

    @Override
    public void onClick(View v) {
        rd1.setChecked(false);

    }
});

    }


}
